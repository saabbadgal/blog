@extends('blog.layouts.app')




@section('content')

@include('blog.layouts.header')
 
 
 
 
 
@include('blog.layouts.footer')
@endsection