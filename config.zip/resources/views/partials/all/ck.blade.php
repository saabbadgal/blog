 


    <script src="{{asset('ck/ckeditor.js')}}"></script>
    <style>.cke{visibility:hidden;}</style>
    <script src="{{asset('ck/sample.js')}}"></script>
    <link rel="stylesheet" href="{{asset('ck/samples.css')}}">
    <link rel="stylesheet" href="{{asset('ck/neo.css')}}">
    <script type="text/javascript" src="{{asset('ck/config.js')}}"></script>
    <link rel="stylesheet" type="text/css" href="{{asset('ck/editor.css')}}">
    <script type="text/javascript" src="{{asset('ck/en.js')}}"></script>
    <script type="text/javascript" src="{{asset('ck/styles.js')}}"></script>
    <link rel="stylesheet" type="text/css" href="{{asset('ck/scayt.css')}}">
    <link rel="stylesheet" type="text/css" href="{{asset('ckdialog.css')}}">
    <link rel="stylesheet" type="text/css" href="{{asset('ck/tableselection.css')}}">
    <link rel="stylesheet" type="text/css" href="{{asset('ck/wsc.css')}}">
    <link rel="stylesheet" type="text/css" href="{{asset('ck/dialog.css')}}">
</head>