@extends('auth.user.layouts.app')

@section('content')







<h1>User Dashboard</h1>
<h1>User Dashboard</h1>
<h1>User Dashboard</h1>
<h1>User Dashboard</h1>
<h1>User Dashboard</h1>
<h1>User Dashboard</h1>
<h1>User Dashboard</h1>
<h1>User Dashboard</h1>
<h1>User Dashboard</h1>
<h1>User Dashboard</h1>
<h1>User Dashboard</h1>
<h1>User Dashboard</h1>
<h1>User Dashboard</h1>
<h1>User Dashboard</h1>
<h1>User Dashboard</h1>
<h1>User Dashboard</h1>
<h1>User Dashboard</h1>

@endsection