
<?php $__env->startSection('content'); ?>

<?php
// dd($posts);
?>

<div class="pcoded-main-container">
    <div class="pcoded-wrapper">
        <div class="pcoded-content">
            <div class="pcoded-inner-content">
                <div class="main-body">
                    <div class="page-wrapper">
                        <div class="row">
                            
<div class="col-md-12">
    <div class="card">
        <div class="card-header bg-primary">
                              <h4 class="text-white">Main Post</h4>
                          </div>
                      </div>

			<div class="row pt-2">
				<div class="col-md-4">
					<img class="img-fluid card-img-top" src="<?php echo e(url('uploads/'.$post->image)); ?> " alt="Card image cap">
				</div>
				<div class="col-md-8">
					<div class="card-body">
				<h3 class="card-title"><?php echo e($post->subtitle); ?> </h3>
				<h5 class="card-title"><?php echo e($post->subtitle); ?> </h5>
				<p class="card-text"><?php echo e($post->body); ?> </p>
				
					<div class="d-inline-flex ">
				 
						<a class="d-inline" href="<?php echo e(route('post.edit',$post->id)); ?> "><button type="button" class="btn btn-sm btn-info d-inline">Edit</button></a>
				 
						
				<form action="<?php echo e(route('post.destroy',$post->id)); ?>" method="post">
                  <?php echo csrf_field(); ?>
                  <?php echo method_field('DELETE'); ?>
                  <button type="submit" name="submit" class="btn btn-sm btn-danger">Delete</button>
               </form>
  
						<a href="<?php echo e(route('paragraph.make',['post_id' => $post->id ])); ?> "><button class="btn btn-sm btn-primary">Add Paragraph</button></a> 
					</div>
 
				</div>
				
				
			</div>
				</div>
		 
  <div class="card w-100">
			  <div class="card-header bg-primary">
                              <h4 class="text-white">All Paragraphs</h4>
                          </div>
                      </div>

 
	<div class="card-columns">
		<?php $__currentLoopData = $post->paragraphs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $paragraph): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		
		<div class="card">
			<img class="img-fluid card-img-top" src="<?php echo e(asset('uploads/'.$paragraph->image)); ?>" alt="Card image cap">
			
			<div class="card-body">
				<h5 class="card-title"><?php echo e($paragraph->title); ?> </h5>
				<p class="card-text"> <?php echo e($paragraph->body); ?></p>
				<a href="<?php echo e(route('paragraph.edit',$paragraph->id)); ?> "><button class="btn btn-primary">Edit</button></a>
				<form action="<?php echo e(route('paragraph.destroy',$paragraph->id)); ?> " method="post" class="d-inline">
					<?php echo csrf_field(); ?>
					<?php echo method_field('DELETE'); ?>
					<button name="submit" class="btn btn-danger">Delete</button>
				</form>
			<button class="btn btn-info">Sort : <?php echo e($paragraph->sort); ?> </button>
			</div>
		</div>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		
	</div>
</div>
					</div>
				</div>
			</div>
		</div>
	</div>
 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\blog\resources\views/admin/post/post.blade.php ENDPATH**/ ?>