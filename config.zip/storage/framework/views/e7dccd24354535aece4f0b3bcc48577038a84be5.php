<?php $__env->startSection('meta'); ?>
<meta name="description" content="<?php echo e($meta->description ?? ''); ?>">
<meta name="keywords" content="<?php echo e($meta->keywords ?? ''); ?>">
<title><?php echo e($meta->title ??  'Blog'); ?></title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('blog.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('blog.layouts.slider', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php if(Session::has('msg')): ?>
<div id="alert" class="alert alert-warning alert-dismissible fade show" role="alert" >
	<?php echo e(Session::get('msg')); ?>

	<button  id="close" type="button" class="close" data-dismiss="alert" aria-label="Close">
	<span aria-hidden="true">&times;</span>
	</button>
</div>
</div>
<?php endif; ?>
<div class="container">
<div class="row mt-lg-3 ">
	<div class="col-12  pt-3">
		<div class="card">
			<div class="card-header">
				
				
				<h5 class="mb-0">Latest Posts</h5>
			</div>
		</div>
	</div>
	<span class="animate-border ml-3 tw-mt-20"></span>
</div>
<div class="row">
	
	<div class="col-lg-9 mb-4">
		<?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<div class="row pt-lg-4 mb-lg-4">
			<div class="col-lg-5">
				<a href="<?php echo e($post->path()); ?>"><img src="<?php echo e(asset('uploads/'.$post->image)); ?>" alt="<?php echo e($post->image_alt); ?> " class="img-fluid rounded "></a>
			</div>
			<div class="col-lg-7">
				<div class="entry2">
					
					<div class="excerp">
						
						<h2 class="pt-2 mb-2  text-dark"><a class="p-h" href="<?php echo e($post->path()); ?> "><?php echo e($post->title); ?> </a></h2>
						
						<p class="p-s"><?php echo Str::limit($post->body, $limit = 250, $end = '..'); ?> <a href="<?php echo e($post->path()); ?> ">...Read more</a> </p>
						<div class="post-meta align-items-center text-left clearfix">
						<figure class="author-figure mb-0 mr-3 float-left"></figure>
						<span class="d-inline-block mt-1"><i class="fas fa-user text-dark"></i> &nbsp;<a href="#"><?php echo e($post->user->name); ?> </a></span>
						
						<span class="text-dark">&nbsp;&nbsp; <?php echo e(date_format($post->created_at,"M d,Y")); ?></time><?php echo e(" · ". $post->reading_time); ?> read </span>

					</div>
					
				</div>
			</div>
		</div>
	</div>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	<div class="row justify-content-end pt-5">
		<?php echo e($posts->links()); ?>

	</div>
</div>
<?php echo $__env->make('blog.postsidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
</div>
<?php echo $__env->make('blog.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('blog.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\blog2\blog\resources\views/blog/index.blade.php ENDPATH**/ ?>