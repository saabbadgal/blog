
<?php $__env->startSection('content'); ?>

<?php
// $id = $post_id;
?>
<div class="pcoded-main-container">
    <div class="pcoded-wrapper">
        <div class="pcoded-content">
            <div class="pcoded-inner-content">
                <div class="main-body">
                    <div class="page-wrapper">
                        <div class="row">
                            <div class="col-md-12">
    <div class="card">
        <div class="card-header bg-primary">
            <h4 class="text-white">Edit Paragraph for the post</h4>
        </div>
        <div class="row pt-2">
            <div class="col-md-3">
                <img class="img-fluid card-img-top" src="<?php echo e(asset('uploads/'.$paragraph->post->image)); ?> " alt="Card image cap">
            </div>
            <div class="col-md-9">
                <div class="card-body">
                    <h3 class="card-title"><?php echo e($paragraph->post->subtitle); ?> </h3>
                    <h5 class="card-title"><?php echo e($paragraph->post->subtitle); ?> </h5>
                    <p class="card-text"><?php echo e($paragraph->post->body); ?> </p>
                </div>
            </div>
        </div>
        
    </div>
</div>

                            
                            <div class="col-sm-12">
                                <div class="card">
                                    <div class="card-header">
                                        <h5>Edit Paragraph</h5>
                                    </div>
                                    <div class="card-body">
                                        <div class="row">
                                            <div class="col-md-12">
<form method="post" action="<?php echo e(route('paragraph.update',$paragraph->id)); ?>" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
   <?php echo method_field('PATCH'); ?>
    <div class="form-group">
        <label class="">Title </label>
        <input type="text" name="title" value="<?php echo e($paragraph->title); ?> " class="form-control" placeholder="Enter Title"arial-invalid="false" required>
        <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <span class=" error jquery-validation-error form-text text-danger"><?php echo e($message); ?> </span>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
    
    <div class="form-group">
        <label for="exampleFormControlTextarea1">Body</label>
        <textarea  name="body" class="form-control" id="exampleFormControlTextarea1" rows="3"><?php echo e($paragraph->body); ?></textarea>
    </div>
    <div class="row">
        <div class="col-md-2 d-block">
            <div class="form-group">
                <label for="inputState">Status</label>
                <select name="status" id="inputState" class="form-control">
                    <option value="1" selected="">Active</option>
                    <option value="0">Inactive</option>
                </select>
            </div>
        </div>
        <div class="col-md-2 d-block">
            <div class="form-group">
                <label>Sort</label>
                <input value="<?php echo e($paragraph->sort); ?>" type="" name="sort" class="form-control" placeholder="Sort">
                <?php $__errorArgs = ['sort'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class=" error jquery-validation-error form-text text-danger"><?php echo e($message); ?> </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>
        
        <div class="col-md-8"></div>
         <div class="col-md-2">
             <label for="inputState">Old Image</label>
            <img src="<?php echo e(asset('uploads/'.$paragraph->image)); ?> " alt="" class="img-thumbnail">
        </div>
        <div class="col-md-6 d-block">
            <div class="form-group">
                <label for="inputState">Choose Image</label>
               <input name="image" id="input-b1" name="input-b1" type="file" class="file" data-browse-on-zone-click="true">
                
            </div>
        </div>
             <div class="col-md-4 row align-items-end">

            <div class="form-group">
                <label for="inputState">Default Size (1366 X 768)</label>
            <div class="input-group">
<div class="input-group-prepend">
<span class="input-group-text bg-primary text-white">Size in Pixels</span>
</div>
<input type="text" name="width" value=" " class="form-control">
<input type="text" name="height" value=" " class="form-control">
</div>
        </div>
    </div>
          <div class="col-md-6 d-block">
                                <div class="form-group">
                                     <label class="">Image Alt Name </label>
                                    <input type="tesxt" name="image_alt" value="<?php echo e($paragraph->image_alt); ?>" class="form-control" placeholder="Image Alt Name"  required>
                                </div>
                            </div>
        <div class="col-md-2  d-flex align-items-end">
            <div class="form-group">
                <label>&nbsp;</label>
                <button type="submit" class="form-control btn  btn-success" name="submit" >Update</button>
                
            </div>
        </div> 
           
        </div>
    </div>
</form>

    
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<script>
window.setTimeout(function() {
$("#success-alert").fadeTo(500, 0).slideUp(500, function(){
$(this).remove();
});
}, 2000);
$(document).ready(function() {
$('.js-example-basic-multiple').select2();
});
</script>
<!--end container-->
<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\blog\resources\views/admin/paragraph/edit.blade.php ENDPATH**/ ?>