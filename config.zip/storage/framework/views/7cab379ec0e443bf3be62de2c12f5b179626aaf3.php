
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('blog.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php
dd($post);
?>
<section class="site-section bg-s">
	<div class="container ">
		<div class="row blog-entries element-animate">
			<div class="col-md-12 col-lg-8 main-content bg-white pt-4">
				
				<div class="post-content-body">
					<div class="media">
						<div class="post-format-icon post-format-standar">
							<i class="fa fa-pencil"></i>
						</div>
						<div class="media-body">
							<h2 class="post-h"><a href="single.html" class="post-h">The AI magically removes moving objects from videos.</a></h2>
							
							<div class="post-meta mb-0 clearfix">
								<ul><li><i class="fa fa-user"></i><a href="https://unlockpress.com/author/tunafish" rel="author">tunafish</a></li><li><i class="fa fa-clock-o"></i><time class="entry-date published" datetime="2019-01-30T14:30:51+00:00">30.01.2019</time></li>  </ul> </div>
							</div>
						</div>
						<hr>
						<div class="row mb-2 mt-1">
							<div class="col-md-12 mb-2">
								<img style="" src="https://via.placeholder.com/740x302" alt="Image placeholder" class="img-fluid rounde">
							</div>
						</div>
						
						
						
						
						<p class="p-s-s">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Praesentium nam quas inventore, ut iure iste modi eos adipisci ad ea itaque labore earum autem nobis et numquam, minima eius. Nam eius, non unde ut aut sunt eveniet rerum repellendus porro.</p>
                         
						<hr>
						<h2 class="post-h"><a href="single.html" class="post-h">The AI magically removes moving objects from videos.</a></h2>
						<p class="p-s-s">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Praesentium nam quas inventore, ut iure iste modi eos adipisci ad ea itaque labore earum autem nobis et numquam, minima eius. Nam eius, non unde ut aut sunt eveniet rerum repellendus porro.</p>


						<hr>
						<div class="card mb-2">
							<div class="card-header">
								Categories :
<span class="badge badge-primary p-2">Primary</span>
<span class="badge badge-primary p-2">Primary</span>
<span class="badge badge-primary p-2">Primary</span>
<span class="badge badge-primary p-2">Primary</span>
							</div>
						</div>
						<div class="card">
							<div class="card-header">
								Tags : 
<span class="badge badge-primary p-2">Primary</span>
<span class="badge badge-primary p-2">Primary</span>
<span class="badge badge-primary p-2">Primary</span>
<span class="badge badge-primary p-2">Primary</span>
							</div>
						</div>
						<!--Light blue-->
       
					</div>
					 
				</div>
				<div class="col-lg-1"></div>
				<div class="col-lg-3  pt-lg-">

		<div class="card mb-4">
			<!-- Card header -->
			<div class="card-header text-center">All Categories</div>
			<!--Card content-->
			<div class="card-body">
				<ul class="list-group">
					<?php
					$cats = $categories->count();
					?>
					<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<li class="list-group-item d-flex justify-content-between align-items-center">
						<?php echo e($category->name); ?>

						<span class="badge btn-deep-orange badge-pill"><?php echo e($category->posts()->count()); ?> </span>
					</li>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					
				</ul>
			</div>
			
		</div>
		<div class="card mb-4">
			<!-- Card header -->
			<div class="card-header text-center">All Tags</div>
			<!--Card content-->
			<div class="card-body">
				<?php $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<a href=" " class="badge btn-deep-orange mr-2 p-2 mb-2"><?php echo e($tag->name); ?> </a>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</div>
		</div>
		
	</div>
				
				
			</div>
		</div>
	</section>
	<?php echo $__env->make('blog.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	<?php $__env->stopSection(); ?>
<?php echo $__env->make('blog.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\blog\resources\views/blog\post.blade.php ENDPATH**/ ?>