
<?php $__env->startSection('content'); ?>
<div class="pcoded-main-container">
<div class="pcoded-wrapper">
<div class="pcoded-content">
<div class="pcoded-inner-content">
<div class="main-body">
<div class="page-wrapper">
<div class="row">
<div class="col-sm-12">
<div class="card">
<div class="card-header">
<h5>Edit Profile</h5>
</div>
<div class="card-body">
<div class="row">
<div class="col-md-12">
<form method="post" action="<?php echo e(route('main.profile.update',$profile->id)); ?> ">
    <?php echo csrf_field(); ?> 
    <?php echo method_field('PATCH'); ?>
    <div class="row">
        <div class="col-md-8">
            <div class="row">
                <div class="col-md-12 d-block">
                    <div class="form-group">
                        <label>Facebook</label>
                        <input type="text" value="<?php echo e($profile->facebook); ?>" name="facebook" class="form-control" placeholder="Enter Facebook">
                        <?php $__errorArgs = ['facebook'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class=" error jquery-validation-error form-text text-danger"><?php echo e($message); ?> </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
                <div class="col-md-12 d-block">
                    <div class="form-group">
                        <label>Instagram</label>
                        <input type="text" value="<?php echo e($profile->instagram); ?>" name="instagram" class="form-control" placeholder="Enter Instagram">
                        <?php $__errorArgs = ['instagram'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class=" error jquery-validation-error form-text text-danger"><?php echo e($message); ?> </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
                <div class="col-md-12 d-block">
                    <div class="form-group">
                        <label>Gmail</label>
                        <input type="text" value="<?php echo e($profile->gmail); ?>" name="gmail" class="form-control" placeholder="Enter Gmail">
                        <?php $__errorArgs = ['gmail'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class=" error jquery-validation-error form-text text-danger"><?php echo e($message); ?> </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
                <div class="col-md-12 d-block">
                    <div class="form-group">
                        <label>Phone</label>
                        <input type="text" value="<?php echo e($profile->phone); ?>" name="phone" class="form-control" placeholder="Enter Phone">
                        <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class=" error jquery-validation-error form-text text-danger"><?php echo e($message); ?> </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
                  <div class="col-md-6 d-block mt-3">
                <div class="form-group">
                    <button type="submit" name="submit" class="btn  btn-success mt-2" title="" data-toggle="tooltip" data-original-title="btn btn-gradient-success">Update Profile</button>
                </div>
            </div>
            </div>
        </div>
    </div>
</form>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\blog\resources\views/admin/profile/edit.blade.php ENDPATH**/ ?>