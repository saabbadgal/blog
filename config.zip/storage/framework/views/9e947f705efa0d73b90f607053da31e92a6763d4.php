
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
<div class="page-head">
    <h4 class="my-2">Create Post</h4>
</div>
<div class="row">
        <div class="col-12">
            <div class="card m-b-30">
                <div class="card-body">
                    <h5 class="header-title pb-3">Basic horizontal xample</h5>
                    <div class="general-label">
                        <div class="form-group row">
                            <label for="example-search-input" class="col-2 col-form-label">Title</label>
                            <div class="col-10">
                                <input class="form-control" name="title" type="text" id="example-search-input">
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="example-search-input" class="col-2 col-form-label">Subtitle</label>
                            <div class="col-10">
                                <input class="form-control" name="subtitle" type="text" id="example-search-input" placeholder="Subtitile">
                            </div>
                        </div><div class="form-group row">
                        <label for="example-search-input" class="col-2 col-form-label">Slug</label>
                        <div class="col-10">
                            <input class="form-control" name="slug" type="text" id="example-search-input" placeholder="Slug">
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>




<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\blog\resources\views/admin\post\create.blade.php ENDPATH**/ ?>