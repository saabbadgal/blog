
<?php $__env->startSection('content'); ?>




<div class="pcoded-main-container">
   <div class="pcoded-wrapper">
      <div class="pcoded-content">
         <div class="pcoded-inner-content">
            <div class="main-body">
               <div class="page-wrapper">
                  <div class="row">
                     <div class="col-sm-12">
                        <div class="card">
                           <div class="card-header">
                              <h5>Create Category</h5>
                           </div>
                           <div class="card-body">
                              <div class="row">
                                 <div class="col-md-6">
                                    <form method="post" action="<?php echo e(route('category.store')); ?> ">
                                       <?php echo csrf_field(); ?>
                                       <div class="form-group">
                                          <label>Name</label>
                                          <input type="text" name="name" class="form-control" placeholder="Enter Name">
                                           <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class=" error jquery-validation-error form-text text-danger"><?php echo e($message); ?> </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                          <button type="submit" name="submit" class="btn btn-sm btn-success mt-2">Save</button>
                                       </div>
                                    </form>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                          <div class="col-xl-12 col-md-12">
                           <div class="card">
                              <div class="card-header">
                                 <h5>All Categories</h5>
                              </div>
                              <div class="card-body table-border-style">
                                 <div class="table-responsive">
                                    <table class="table table-bordered">
                                       <thead>
                                          <tr>
                                             <th>ID</th>
                                             <th>Name</th>
                                             <th>Slug</th>
                                             <th>Total Posts</th>
                                             <th>Edit</th>
                                             <th>Delete</th>
                                          </tr>
                                       </thead>
                                       <tbody>
                                             <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                          <tr>
                                             <td><?php echo e($category->id); ?>  </td>
                                             <td><?php echo e($category->name); ?></td>
                                             <td><?php echo e($category->slug); ?></td>
                                             <td><?php echo e($category->posts->count()); ?></td>
                                             <td><a href="<?php echo e(route('category.edit',$category->id)); ?> "><button type="button" class="btn btn-sm btn-warning"><i class="feather icon-delete"></i>Edit</button></a></td>
                                             <td>
                                             <form action="<?php echo e(route('category.destroy',$category->id)); ?>" method="post">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                             <button type="submit" name="submit" class="btn btn-sm btn-danger"><i class="feather icon-slash"></i>Delete</button></form></td>
                                             

                                          </tr>
                                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                                       </tbody>
                                    </table>
                                 </div>
                              </div>
                           </div>
                        </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </div>
</div>
 

    
    
      <script>
      window.setTimeout(function() {
      $("#success-alert").fadeTo(500, 0).slideUp(500, function(){
      $(this).remove();
      });
      }, 2000);
      </script>
      <!--end container-->
      <?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\blog\resources\views/admin/category/index.blade.php ENDPATH**/ ?>