    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="Mannat Themes">
    <meta name="keyword" content="">

    <title>Blog</title>
        <link rel="icon" href="http://html.phoenixcoded.net/elite-able/bootstrap/assets/images/favicon.ico" type="image/x-icon">

        <link rel="stylesheet" href="<?php echo e(asset('assets/fonts/fontawesome/css/fontawesome-all.min.css')); ?>"> 
        <link rel="stylesheet" href="<?php echo e(asset('assets/plugins/animation/css/animate.min.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('assets/plugins/notification/css/notification.min.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('assets/plugins/bootstrap-tagsinput-latest/css/bootstrap-tagsinput.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('assets/plugins/select2/css/select2.min.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('assets/plugins/multi-select/css/multi-select.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('assets/plugins/bootstrap/css/bootstrap.min.css')); ?>"> 
        <link rel="stylesheet" href="<?php echo e(asset('assets/css/fileinput-rtl.min.css')); ?>"> 
        <link rel="stylesheet" href="<?php echo e(asset('assets/css/fileinput.min.css')); ?>"> 
        <link rel="stylesheet" href="<?php echo e(asset('assets/css/style.css')); ?>">

        <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-beta.1/dist/css/select2.min.css" rel="stylesheet" />
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-beta.1/dist/js/select2.min.js"></script><?php /**PATH C:\xampp\htdocs\blog\resources\views/partials/all/css.blade.php ENDPATH**/ ?>