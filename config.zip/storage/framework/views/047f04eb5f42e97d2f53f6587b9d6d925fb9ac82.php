

<?php $__env->startSection('meta'); ?> 
<title><?php echo e($post->meta_title ?? ''); ?></title>
<meta name="description" content="<?php echo e($post->meta_description ?? ''); ?>">
<meta name="keywords" content="<?php echo e($post->meta_keywords ?? ''); ?>">
   
<?php $__env->stopSection(); ?> 
 







<?php $__env->startSection('content'); ?>
<?php echo $__env->make('blog.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
 
<section class="site-section bg-s">
	<div class="container ">
		<div class="row blog-entries element-animate">
			<div class="col-md-12 col-lg-8 main-content bg-white pt-4">
				
				<div class="post-content-body">
					<div class="media">
						<div class="post-format-icon post-format-standar">
							<i class="fa fa-pencil"></i>
						</div>
						<div class="media-body">
							<h2 class="post-h"><?php echo e($post->title); ?> </h2> 
							
							<div class="post-meta mb-0 clearfix">
								<ul><li class="text-dark"><i class="fa fa-user"></i><a class="text-dark"><?php echo e($post->user->name); ?> </a></li><li class="text-dark"><i class="fa fa-clock-o"></i><time class="entry-date published" datetime="2019-01-30T14:30:51+00:00"> <?php echo e(date_format($post->created_at,"M d,Y")); ?></time><?php echo e(" · ". $post->reading_time); ?> read</li> </ul> </div>
							</div>
						</div>
						<hr>
						<div class="row mb-2 mt-1  justify-content-center">
							<div class="col-sm-12 mb-2  text-center">
								<img src="<?php echo e(asset('uploads/'.$post->image)); ?>" alt="<?php echo e($post->image_alt); ?> " class="img-fluid rounde"  style="width: <?php echo e($post->width); ?>px !important; height: <?php echo e($post->height); ?>px !important; ">
							</div>
					
						
						</div>

						
						<p class="p-s-s"><?php echo $post->body; ?></p>
						<?php if($post->paragraphs): ?>
						<?php $__currentLoopData = $post->paragraphs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $paragraph): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<hr>
						<div class="row mb-2 mt-1 justify-content-center">
							<div class="col-sm-9 mb-2 text-center">
								<img src="<?php echo e(asset('uploads/'.$paragraph->image)); ?>" alt="<?php echo e($post->image_alt); ?> " class="img-fluid rounde" style="width: <?php echo e($paragraph->width); ?>px !important ; height: <?php echo e($paragraph->height); ?>px !important;">
							</div>
						</div>
						<h2 class="post-h"><?php echo e($paragraph->title); ?></h2>
						<p class="p-s-s"><?php echo $paragraph->body; ?></p>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						<?php endif; ?>
						<hr>
						<div class="card mb-2">
							<div class="card-header py-1">
								 					<button type="button" class="btn btn-sm btn-fb"><i class="fab fa-facebook-f"></i></button>
					 						<button type="button" class="btn btn-sm btn-tw"><i class="fab fa-twitter"></i></button>
					 
						<button type="button" class="btn btn-sm btn-gplus"><i class="fab fa-google-plus-g"></i></button>
						<button type="button" class="btn btn-sm btn-li"><i class="fab fa-linkedin-in"></i></button>
					 
							</div>
						</div>
						<div class="card mb-2">
							<div class="card-header">
								Categories :
								
								<?php $__currentLoopData = $post->categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<a class="badge badge-primary p-2" href="<?php echo e($categor->path()); ?> "><?php echo e($categor->name); ?> </a>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</div>
						</div>
						<div class="card">
							<div class="card-header">
								Tags :
								<?php $__currentLoopData = $post->tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<a class="badge badge-primary p-2" href="<?php echo e($ta->path()); ?>"><?php echo e($ta->name); ?> </a>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</div>
						</div>
						<!--Light blue-->
						
					</div>
					
				</div>
				<div class="col-lg-1"></div>
		  <?php echo $__env->make('blog.postsidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 
			</div>
		</div>
	</section>
	<?php echo $__env->make('blog.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	<?php $__env->stopSection(); ?>
<?php echo $__env->make('blog.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\blog2\blog\resources\views/blog/post.blade.php ENDPATH**/ ?>