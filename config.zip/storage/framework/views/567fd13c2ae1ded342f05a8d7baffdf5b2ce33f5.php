	<div class="col-lg-3  pt-lg-4">

		<div class="card mb-4">
			<!-- Card header -->
			<div class="card-header text-center">Categories</div>
			<!--Card content-->
			<div class="card-body">
				<ul class="list-group">
					<?php
					$cats = $categories->count();
					 
					?>
					<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<?php
					// dd($category->slug)
					?>
					<li class="list-group-item d-flex justify-content-between align-items-center">
						<a href= "<?php echo e($category->path()); ?> " class="text-dark"><?php echo e($category->name); ?></a>
						<span class="badge btn-deep-orange badge-pill"><?php echo e($category->posts()->count()); ?> </span>
					</li>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					
				</ul>
			</div>
			
		</div>
		<div class="card mb-4">
			<!-- Card header -->
			<div class="card-header text-center">Tags</div>
			<!--Card content-->
			<div class="card-body">
				<?php $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<a href="<?php echo e($tag->path()); ?> " class="badge btn-deep-orange mr-2 p-2 mb-2"><?php echo e($tag->name); ?> </a>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</div>
		</div>
		
	</div><?php /**PATH C:\xampp\htdocs\blog2\blog\resources\views/blog/postsidebar.blade.php ENDPATH**/ ?>