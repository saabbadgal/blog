
<?php $__env->startSection('content'); ?>




<div class="pcoded-main-container">
   <div class="pcoded-wrapper">
      <div class="pcoded-content">
         <div class="pcoded-inner-content">
            <div class="main-body">
               <div class="page-wrapper">
                  <div class="row">
                     <div class="col-sm-12">
                        <div class="card">
                           <div class="card-header">
                              <h5>Create SLider</h5>
                           </div>
                           <div class="card-body">
                              <div class="row">
                                 <div class="col-md-6">
                                    <form method="post" action="<?php echo e(route('slider.store')); ?> "  enctype="multipart/form-data">
                                       <?php echo csrf_field(); ?>

                                
                <div class="form-group">
                    <label for="inputState">Choose Image</label>
                    <input name="image" id="input-b1" name="input-b1" type="file" class="file" data-browse-on-zone-click="true">
                    
                </div>
        
                                       <div class="form-group">
                                        
                                          <button type="submit" name="submit" class="btn btn-sm btn-success mt-2">Save</button>
                                       </div>
                                    </form>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                          <div class="col-xl-12 col-md-12">
                           <div class="card">
                              <div class="card-header">
                                 <h5>All sliders</h5>
                              </div>
                              <div class="card-body table-border-style">
                                 <div class="table-responsive">
                                    <table class="table table-bordered">
                                       <thead>
                                          <tr>
                                             <th>ID</th> 
                                             <th>Image</th>
                                             <th>Delete</th>
                                          </tr>
                                       </thead>
                                       <tbody>
                                             <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                          <tr>
                                             <td><?php echo e($slider->id); ?>  </td>
                                            <td><img class="rounded" style="width:60px;" src="<?php echo e(asset('uploads/'.$slider->slider)); ?>" alt="activity-user"></td>
          
                                         
                                             <td>
                                             <form action="<?php echo e(route('slider.delete',$slider->id)); ?>" method="post">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                             <button type="submit" name="submit" class="btn btn-sm btn-danger"><i class="feather icon-slash"></i>Delete</button></form></td>
                                             

                                          </tr>
                                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                                       </tbody>
                                    </table>
                                 </div>
                              </div>
                           </div>
                        </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </div>
</div>
 

    
    
      <script>
      window.setTimeout(function() {
      $("#success-alert").fadeTo(500, 0).slideUp(500, function(){
      $(this).remove();
      });
      }, 2000);
      </script>
      <!--end container-->
      <?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\check\blog\resources\views/admin/slider/index.blade.php ENDPATH**/ ?>