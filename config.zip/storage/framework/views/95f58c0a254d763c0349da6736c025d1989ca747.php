 

<div class="site-cover site-cover-sm same-height overlay single-page" style="background-image: url('<?php echo e(asset('assetsUser/images/img_2.jpg')); ?>');">
	<div class="container">
		<div class="row same-height justify-content-center py-md-0">
			<div class="col-md-12 col-lg-10">
				<div class="post-entry text-center">
					<span class="post-category text-white bg-success mb-3">Nature</span>
					<h1 class="mb-4"><a href="#">The AI magically removes moving objects from videos.</a></h1>
					<div class="post-meta align-items-center text-center">
					<figure class="author-figure mb-0 mr-3 d-inline-block"><img src="<?php echo e(asset('assetsUser/images/person_1.jpg')); ?>" alt="Image" class="img-fluid"></figure>
					<span class="d-inline-block mt-1">By Carrol Atkinson</span>
					<span>&nbsp;-&nbsp; February 10, 2019</span>
				</div>
			</div>
		</div>
	</div>
</div>
</div><?php /**PATH C:\xampp\htdocs\blog\resources\views/user/post/postheaderimage.blade.php ENDPATH**/ ?>