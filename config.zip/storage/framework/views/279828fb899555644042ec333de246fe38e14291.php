

<script src="<?php echo e(asset('assets/js/vendor-all.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/plugins/bootstrap/js/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/pcoded.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/menu-setting.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/pages/dashboard-analytics.js')); ?>"></script> 

<script src="<?php echo e(asset('assets/js/pages/form-advance-custom.js')); ?>"></script> 

<script src="<?php echo e(asset('assets/plugins/select2/js/select2.full.min.js')); ?>"></script> 
<script src="<?php echo e(asset('assets/plugins/multi-select/js/jquery.quicksearch.js')); ?>"></script> 

<script src="<?php echo e(asset('assets/plugins/multi-select/js/jquery.multi-select.js')); ?>"></script> 

<script src="<?php echo e(asset('assets/js/pages/form-select-custom.js')); ?>"></script> 
<script src="<?php echo e(asset('assets/js/pages/form-validation.js')); ?>"></script> 
<script src="<?php echo e(asset('assets/js/ck.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/fileinput.min.js')); ?>"></script>
<script type="text/javascript">
	$(window).on('load', function() {
		// Inline editor
		InlineEditor.create(document.querySelector('#inline-editor'))
			.catch(error => {
				console.error(error);
			});
	});
</script>      
<script>
       
            jQuery(document).ready(function($) {
                $('.counter').counterUp({
                delay: 100,
                time: 1200
                });
            });
 </script><?php /**PATH C:\xampp\htdocs\check\blog\resources\views/partials/all/js.blade.php ENDPATH**/ ?>