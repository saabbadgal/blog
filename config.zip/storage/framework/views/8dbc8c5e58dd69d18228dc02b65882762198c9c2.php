 

<!-- Swiper -->
<div class="swiper-container">
	<div class="swiper-wrapper">
		
		<div class="swiper-slide"><img class="img-fluid" src="<?php echo e(asset('images/slider/1.jpg')); ?> " alt=""></div>
		<div class="swiper-slide"><img class="img-fluid" src="<?php echo e(asset('images/slider/2.jpg')); ?> " alt=""></div>
		<div class="swiper-slide"><img class="img-fluid" src="<?php echo e(asset('images/slider/3.jpeg')); ?> " alt=""></div>
		<div class="swiper-slide"><img class="img-fluid" src="<?php echo e(asset('images/slider/4.jpeg')); ?> " alt=""></div>
		<div class="swiper-slide"><img class="img-fluid" src="<?php echo e(asset('images/slider/5.jpeg')); ?> " alt=""></div>
	</div>
	<!-- Add Arrows -->
	<div class="swiper-button-next"></div>
	<div class="swiper-button-prev"></div>
</div>
<style>
	
.swiper-container {
	max-height: 500px;
}
.swiper-slide {
text-align: center;
font-size: 18px;
background: #fff;
/* Center slide text vertically */
display: -webkit-box;
display: -ms-flexbox;
display: -webkit-flex;
display: flex;
-webkit-box-pack: center;
-ms-flex-pack: center;
-webkit-justify-content: center;
justify-content: center;
-webkit-box-align: center;
-ms-flex-align: center;
-webkit-align-items: center;
align-items: center;
}
</style>
 <?php /**PATH C:\xampp\htdocs\blog\resources\views/blog/layouts/slider.blade.php ENDPATH**/ ?>