

<?php $__env->startSection('content'); ?>







<h1>User Dashboard</h1>
<h1>User Dashboard</h1>
<h1>User Dashboard</h1>
<h1>User Dashboard</h1>
<h1>User Dashboard</h1>
<h1>User Dashboard</h1>
<h1>User Dashboard</h1>
<h1>User Dashboard</h1>
<h1>User Dashboard</h1>
<h1>User Dashboard</h1>
<h1>User Dashboard</h1>
<h1>User Dashboard</h1>
<h1>User Dashboard</h1>
<h1>User Dashboard</h1>
<h1>User Dashboard</h1>
<h1>User Dashboard</h1>
<h1>User Dashboard</h1>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('auth.user.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\blog\resources\views/auth/user/dashboard/dashboard.blade.php ENDPATH**/ ?>