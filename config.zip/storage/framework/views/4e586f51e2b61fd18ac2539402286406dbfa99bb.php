 <!DOCTYPE html>
<html lang="en">

<!-- Mirrored from colorlib.com/preview/theme/miniblog/index.html by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 12 Jun 2020 05:16:16 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<head>
<title>Mini Blog</title>
<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

		<link href="https://fonts.googleapis.com/css?family=Muli:300,400,700|Playfair+Display:400,700,900" rel="stylesheet">
		<link rel="stylesheet" href="<?php echo e(asset('assetsUser/fonts/icomoon/style.css')); ?>">
		<link rel="stylesheet" href="<?php echo e(asset('assetsUser/css/bootstrap.min.css')); ?>">
		<link rel="stylesheet" href="<?php echo e(asset('assetsUser/css/magnific-popup.css')); ?>">
		<link rel="stylesheet" href="<?php echo e(asset('assetsUser/css/jquery-ui.css')); ?>">
		<link rel="stylesheet" href="<?php echo e(asset('assetsUser/css/owl.carousel.min.css')); ?>">
		<link rel="stylesheet" href="<?php echo e(asset('assetsUser/css/owl.theme.default.min.css')); ?>">
		<link rel="stylesheet" href="<?php echo e(asset('assetsUser/css/bootstrap-datepicker.css')); ?>">
		<link rel="stylesheet" href="<?php echo e(asset('assetsUser/fonts/flaticon/font/flaticon.css')); ?>">
		<link rel="stylesheet" href="<?php echo e(asset('assetsUser/css/aos.css')); ?>">
		<link rel="stylesheet" href="<?php echo e(asset('assetsUser/css/style.css')); ?>">
		
	</head>
	<body>

 
      <?php echo $__env->make('user.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
         
        <?php echo $__env->yieldContent('content'); ?>


      <?php echo $__env->make('user.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>







		<script src="<?php echo e(asset('assetsUser/js/jquery-3.3.1.min.js')); ?>" type="b52386749c15614db8b655e0-text/javascript"></script>
		<script src="<?php echo e(asset('assetsUser/js/jquery-migrate-3.0.1.min.js')); ?>" type="b52386749c15614db8b655e0-text/javascript"></script>
		<script src="<?php echo e(asset('assetsUser/js/jquery-ui.js')); ?>" type="b52386749c15614db8b655e0-text/javascript"></script>
		<script src="<?php echo e(asset('assetsUser/js/popper.min.js')); ?>" type="b52386749c15614db8b655e0-text/javascript"></script>
		<script src="<?php echo e(asset('assetsUser/js/bootstrap.min.js')); ?>" type="b52386749c15614db8b655e0-text/javascript"></script>
		<script src="<?php echo e(asset('assetsUser/js/owl.carousel.min.js')); ?>" type="b52386749c15614db8b655e0-text/javascript"></script>
		<script src="<?php echo e(asset('assetsUser/js/jquery.stellar.min.js')); ?>" type="b52386749c15614db8b655e0-text/javascript"></script>
		<script src="<?php echo e(asset('assetsUser/js/jquery.countdown.min.js')); ?>" type="b52386749c15614db8b655e0-text/javascript"></script>
		<script src="<?php echo e(asset('assetsUser/js/jquery.magnific-popup.min.js')); ?>" type="b52386749c15614db8b655e0-text/javascript"></script>
		<script src="<?php echo e(asset('assetsUser/js/bootstrap-datepicker.min.js')); ?>" type="b52386749c15614db8b655e0-text/javascript"></script>
		<script src="<?php echo e(asset('assetsUser/js/aos.js')); ?>" type="b52386749c15614db8b655e0-text/javascript"></script>
		<script src="<?php echo e(asset('assetsUser/js/main.js')); ?>" type="b52386749c15614db8b655e0-text/javascript"></script>
		<script async src="https://www.googletagmanager.com/gtag/js?id=UA-23581568-13" type="b52386749c15614db8b655e0-text/javascript"></script>
		<script type="b52386749c15614db8b655e0-text/javascript">
		window.dataLayer = window.dataLayer || [];
		function gtag(){dataLayer.push(arguments);}
		gtag('js', new Date());
		gtag('config', 'UA-23581568-13');
		</script>
		<script src="../../../../ajax.cloudflare.com/cdn-cgi/scripts/7089c43e/cloudflare-static/rocket-loader.min.js" data-cf-settings="b52386749c15614db8b655e0-|49" defer=""></script></body>
	</html><?php /**PATH C:\xampp\htdocs\blog\resources\views/user\layouts\app.blade.php ENDPATH**/ ?>