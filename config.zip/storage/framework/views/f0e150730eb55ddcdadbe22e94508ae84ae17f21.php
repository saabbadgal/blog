<?php echo $__env->make('layouts.shared.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="topnav shadow-sm">
    <div class="container-fluid">
        <nav class="navbar navbar-light navbar-expand-lg topbar-nav">
            <div class="collapse navbar-collapse" id="topnav-menu-content">
            <?php echo $__env->make('layouts.shared.app-menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        </nav>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\blog\resources\views/layouts\shared\navbar.blade.php ENDPATH**/ ?>