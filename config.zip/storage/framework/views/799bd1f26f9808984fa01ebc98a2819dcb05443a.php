




<?php $__env->startSection('content'); ?>


 
 
 saab
 
 

<?php $__env->stopSection(); ?>
<?php echo $__env->make('blog.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\blog\resources\views/blog/pages/home.blade.php ENDPATH**/ ?>