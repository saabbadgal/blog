

<?php $__env->startSection('meta'); ?>
<meta name="description" content="<?php echo e($meta->description ?? ''); ?>">
<meta name="keywords" content="<?php echo e($meta->keywords ?? ''); ?>">
<title><?php echo e($meta->title ??  'Blog'); ?></title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('blog.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
 <?php
// dd($posts->posts);
 ?>
 
<div class="container">
	<div class="row mt-lg-3">
		<div class="col-12">
			<div class="card">
				<div class="card-header">
					
					<h5>Tag : <?php echo e($tag); ?> </h5>
				</div>
			</div>
		</div>
		<span class="animate-border ml-3 tw-mt-20"></span>
	</div>

	<div class="row">
			 <?php if(count($posts) < 1): ?>
		<div class="container">
			<h2>No Results Found</h2>
		</div>
		<?php endif; ?>
		<div class="col-lg-9 mb-4">
			<?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<div class="row pt-lg-4 mb-lg-4">
				<div class="col-lg-5">
					<a href="<?php echo e($post->path()); ?>"><img src="<?php echo e(asset('uploads/'.$post->image)); ?>" alt="<?php echo e($post->image_alt); ?> " class="img-fluid rounded pt-md-4"></a>
				</div>
				<div class="col-lg-7">
					<div class="entry2">
						
						<div class="excerp">
							<?php $__currentLoopData = $post->categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<span class="post-category text-white warning-color-dark mb-1"><?php echo e($category->name); ?> </span>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							<h2 class="pt-2 mb-2 p-h text-dark"><a class="p-h"  href="<?php echo e($post->path()); ?> "><?php echo e($post->title); ?> </a></h2>
							
							<p class="p-s"><?php echo e(Str::limit($post->body, $limit = 240, $end = '..')); ?> <a href="<?php echo e($post->path()); ?> ">...Read more</a> </p>
							<div class="post-meta align-items-center text-left clearfix">
							<figure class="author-figure mb-0 mr-3 float-left"></figure>
							<span class="d-inline-block mt-1"><i class="fas fa-user text-dark"></i> &nbsp;<a href="#"><?php echo e($post->user->name); ?> </a></span>
							
							<span class="text-dark">&nbsp;&nbsp; <?php echo e(date("h:i a"). " "  . date_format($post->created_at,"M d,y")); ?> </span>
						</div>
						
			 
						
					</div>
				</div>
			</div>
		</div>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					<div class="row justify-content-end pt-5">
  <?php echo e($posts->links()); ?>

</div>
	</div>

  <?php echo $__env->make('blog.postsidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>

 </div>

 
 
 
<?php echo $__env->make('blog.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('blog.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/oczh82xknf4e/blog/resources/views/blog/tag.blade.php ENDPATH**/ ?>