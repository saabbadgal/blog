<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="Mannat Themes">
    <meta name="keyword" content="">

    <title>Blog</title>

        <link rel="shortcut icon" href="<?php echo e(('assets/images/favicon.ico')); ?>">
        <link href="<?php echo e(asset('assets/plugins/morris-chart/morris.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(asset('assets/css/bootstrap.min.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(asset('assets/css/slidebars.min.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(asset('assets/css/icons.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(asset('assets/css/menu.css')); ?>" rel="stylesheet" type="text/css">
        <link href="<?php echo e(asset('assets/css/style.css')); ?>" rel="stylesheet">

</head>

  <body class="sticky-header">
   
      <?php echo $__env->make('admin.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
         
        <?php echo $__env->yieldContent('content'); ?>


      <?php echo $__env->make('admin.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      
          <!-- jQuery -->
        <script src="<?php echo e(asset('assets/js/jquery-3.2.1.min.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/js/popper.min.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/js/bootstrap.min.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/js/jquery-migrate.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/js/modernizr.min.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/js/jquery.slimscroll.min.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/js/slidebars.min.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/plugins/counter/jquery.counterup.min.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/plugins/waypoints/jquery.waypoints.min.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/plugins/sparkline-chart/jquery.sparkline.min.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/pages/jquery.sparkline.init.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/plugins/chart-js/Chart.bundle.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/plugins/morris-chart/raphael-min.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/plugins/morris-chart/morris.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/pages/dashboard-init.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/js/jquery.app.js')); ?>"></script>
        <script>
            jQuery(document).ready(function($) {
                $('.counter').counterUp({
                delay: 100,
                time: 1200
                });
            });
        </script>
    </body>
</html>
<?php /**PATH C:\xampp\htdocs\blog\resources\views/admin\layouts\main.blade.php ENDPATH**/ ?>