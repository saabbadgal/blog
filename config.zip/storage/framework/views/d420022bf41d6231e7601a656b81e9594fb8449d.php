 


    <script src="<?php echo e(asset('ck/ckeditor.js')); ?>"></script>
    <style>.cke{visibility:hidden;}</style>
    <script src="<?php echo e(asset('ck/sample.js')); ?>"></script>
    <link rel="stylesheet" href="<?php echo e(asset('ck/samples.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('ck/neo.css')); ?>">
    <script type="text/javascript" src="<?php echo e(asset('ck/config.js')); ?>"></script>
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('ck/editor.css')); ?>">
    <script type="text/javascript" src="<?php echo e(asset('ck/en.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('ck/styles.js')); ?>"></script>
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('ck/scayt.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('ckdialog.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('ck/tableselection.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('ck/wsc.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('ck/dialog.css')); ?>">
</head><?php /**PATH C:\xampp\htdocs\blog2\blog\resources\views/partials/all/ck.blade.php ENDPATH**/ ?>