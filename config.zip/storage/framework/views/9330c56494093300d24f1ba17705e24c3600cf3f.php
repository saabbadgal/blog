

<?php $__env->startSection('content'); ?>


                <div class="container-fluid">
                    <div class="page-head">
                        <a href="<?php echo e(route('tag.index')); ?> " class="btn btn-info d-inline">Back</a>
                        <h4 class="my-2 ml-3  d-inline">Create tag</h4>
                    </div>
                    <div class="row">
                        <div class="col-6">
                            <div class="card m-b-30 pr-4">
                                <div class="card-body mt-3 ">
                                     <div class="general-label">
                                        <form method="post" action="<?php echo e(route('tag.store')); ?> ">   
                                            <?php echo csrf_field(); ?>                                          
                                            <div class="form-group row">
                                                <label for="example-search-input" class="col-2 col-form-label">Name :</label>
                                                <div class="col-10">
                                                    <input class="form-control" name="name" type="text" id="example-search-input">
                                                </div>
                                            </div>
                                            <div class="form-group row">
                                                <label for="example-search-input" class="col-2 col-form-label">Slug :</label>
                                                <div class="col-10">
                                                    <input class="form-control" name="slug" type="text" id="example-search-input">
                                                </div>
                                            </div>
                                             <div class="form-group row">
                                                 
                                                <div class="col-2">
                                                     
                                                </div>
                                                <div class="col-10">
                                                    <button type="submit" name="submit" class="btn btn-success ">Save</button>
                                                </div>
                                            </div>
                                            
                                       
                                        </form>                                    
                                    </div>     
                                                              
                                </div>
                            </div>
                        </div>
                    </div><!--end row-->
                    
                </div><!--end container-->

           


<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\blog\resources\views/admin/tag/create.blade.php ENDPATH**/ ?>