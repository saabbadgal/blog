<!DOCTYPE html>
<html lang="en">
<head>
   <?php echo $__env->make('partials.all.css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


     <style>
        .bg-s{
        background-image: url(' <?php echo e(asset('raw/bg-s.png')); ?>  ');
        background-repeat: repeat;
        }
        .sticky-header .logo {
        /*position: fixed;*/
        top: 0;
        left: 0;
        width: 240px;
        z-index: 100;
        }
        .sticky-header .header-section {
        position: relative;
        
        }
        .sticky-header .right-notification {
        margin-right: 0px;
        }
        .sticky-header .header-section {
        position: ;}
        </style>
</head>

  <body class="sticky-header bg-s">

 
   
      <?php echo $__env->make('auth.admin.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
         
        <?php echo $__env->yieldContent('content'); ?>


      <?php echo $__env->make('auth.admin.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      
       <?php echo $__env->make('partials.all.js', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

       
    </body>
</html>
<?php /**PATH C:\xampp\htdocs\blog\resources\views/auth/admin/layouts/app.blade.php ENDPATH**/ ?>