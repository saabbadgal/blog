
<?php $__env->startSection('content'); ?>
<div class="pcoded-main-container">
    <div class="pcoded-wrapper">
        <div class="pcoded-content">
            <div class="pcoded-inner-content">
                <div class="main-body">
                    <div class="page-wrapper">
                        <div class="row">
                            <div class="col-sm-12">
                                <div class="card">
                                    <div class="card-header">
                                        <h5>Create Category</h5>
                                    </div>
                                    <div class="card-body">
                                        <div class="row">
                                            <div class="col-md-6">
                                                <form method="post" action="<?php echo e(route('category.store')); ?> ">
                                                    <?php echo csrf_field(); ?>
                                                    <div class="form-group">
                                                        <label>Title</label>
                                                        <input type="text" name="name" class="form-control" placeholder="Text">
                                                        <button type="submit" name="submit" class="btn btn-gradient-success mt-2" title="" data-toggle="tooltip" data-original-title="btn btn-gradient-success">Save</button>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\blog\resources\views/admin/category/create.blade.php ENDPATH**/ ?>