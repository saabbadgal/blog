 
<nav class="navbar navbar-expand-lg navbar-light white p-lg-0">

  

    <a class="navbar-brand pl-md-3" href="#">
      <img src="<?php echo e(asset('images/logo-light.jpg')); ?> " height="70" alt="logo">
    </a>

    <!-- Collapse button -->
    <button class="navbar-toggler" id="my-btn-s" type="button" data-toggle="collapse" data-target="#basicExampleNav" aria-controls="basicExampleNav" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
   </button>

    <!-- Links -->
    <div class="collapse navbar-collapse" id="basicExampleNav">

      <!-- Left -->
      <ul class="navbar-nav mx-auto">
         <li class="nav-item">
          <a class="nav-link waves-effect" href="<?php echo e(route('blog.index')); ?> ">Home </a>
        </li>
        <li class="nav-item">
          <a class="nav-link waves-effect" href="<?php echo e(route('blog.about')); ?> ">About Us </a>
        </li>
        <li class="nav-item">
          <a class="nav-link waves-effect" href="<?php echo e(route('blog.contact')); ?> ">Contact Us </a>
        </li>
        <li class="nav-item dropdown" id="navbardrop">
      <a class="nav-link dropdown-toggle" href="#"  data-toggle="dropdown">
        Marketing
      </a>
      <div class="dropdown-menu" id="drop-menu"  style="width: 220px">
         <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

          <?php if($category->slug == "learn-marketing"): ?>
          <a href= "<?php echo e($category->path()); ?> " class="text-dark dropdown-item"><?php echo e($category->name); ?></a>
          <?php elseif($category->slug == "tips-and-tricks"): ?>
          <a href= "<?php echo e($category->path()); ?> " class="text-dark dropdown-item"><?php echo e($category->name); ?></a>

 

          <?php endif; ?>
 
        
          

          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
      </div>
    </li>  
     <li class="nav-item dropdown"   id="navbardrop2">
      <a class="nav-link dropdown-toggle" href="#"  data-toggle="dropdown">
       Digital Marketing
      </a>
      <div class="dropdown-menu" id="drop-menu2"  style="width: 200px">
         <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

          <?php if($category->slug == "tips-and-tricks-dm"): ?>
          <a href= "<?php echo e($category->path()); ?> " class="text-dark dropdown-item"><?php echo e($category->name); ?></a>
          <?php elseif($category->slug == "learn-digital-marketing"): ?>
          <a href= "<?php echo e($category->path()); ?> " class="text-dark dropdown-item"><?php echo e($category->name); ?></a>

 

          <?php endif; ?>
 
        
          

          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
      </div>
    </li>
        
        
      </ul>

      <!-- Right -->
      <ul class="navbar-nav nav-flex-icons ">
        <li class="nav-item">
          <a href="<?php echo e($profile->facebook); ?>" class="nav-link waves-effect" target="_blank">
            <i class="fab fa-facebook-f"></i>
          </a>
        </li> 
        <li class="nav-item">
          <a href="<?php echo e($profile->instagram); ?>" class="nav-link waves-effect" target="_blank">
            <i class="fab fa-instagram"></i>
          </a>
        </li>
      </ul>
      <ul class="navbar-nav nav-flex-icons ">
        <li class="nav-item">
          <a href="mailto:<?php echo e($profile->gmail); ?>" class="nav-link waves-effect"
             target="_blank">
         <i class="far fa-envelope"></i>
            <?php echo e($profile->gmail); ?>

          </a>
        </li>
      </ul>

      <ul class="navbar-nav nav-flex-icons ">
        <li class="nav-item">
          <a href="tel:<?php echo e($profile->phone); ?>" class="nav-link waves-effect"
             target="_blank">
<i class="fas fa-mobile-alt"></i>
           <?php echo e($profile->phone); ?>

          </a>
        </li>
      </ul>

      <ul class="navbar-nav nav-flex-icons pt-md-4">
        <li class="nav-item">
         <!-- Search form -->
<div class="active-pink-4 mb-4 d-inline-flex ml-lg-2 pr-md-3">
  <form method="post" action="<?php echo e(route('blog.search')); ?> ">
    <?php echo csrf_field(); ?>
 
  <input class="form-control d-inline"  name="search" type="text" placeholder="Search Article" aria-label="Search">
  <button type="submit" class="btn btn-sm btn-mdb-color px-3 d-none"><i class="fas fa-search"></i></button>
  
</form> 
</div>
<!-- Search form -->
        </li>
      </ul>

    </div>

 

</nav>
<!--/.Navbar-->
 





 
<script>

</script><?php /**PATH C:\xampp\htdocs\blog\resources\views/blog/layouts/header.blade.php ENDPATH**/ ?>