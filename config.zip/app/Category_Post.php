<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Category_Post extends Model
{
    protected $table = 'category_posts';
}
